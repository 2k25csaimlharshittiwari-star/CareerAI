import json
ROLE_SKILLS={
 'ai/ml engineer':['Python','Machine Learning','Deep Learning','PyTorch','SQL','MLOps'],
 'data scientist':['Python','Pandas','NumPy','SQL','Machine Learning','Statistics'],
 'data analyst':['Python','SQL','Excel','Power BI','Statistics','Pandas'],
 'full stack developer':['HTML/CSS','JavaScript','React','Node.js','SQL','Git/GitHub'],
 'software developer':['Python','Java','C++','DSA','SQL','Git/GitHub'],
 'backend developer':['Python','Java','SQL','REST API','Docker','Git/GitHub'],
 'cybersecurity engineer':['Networking','Linux','Python','Web Security','SIEM','Cloud'],
 'cloud engineer':['Linux','AWS/Azure','Docker','Kubernetes','Networking','Terraform'],
}
def analyze(s, skills, projects, coding, academics, performance):
    role=(s.get('target_role') or 'Software Developer').lower(); req=ROLE_SKILLS.get(role, ROLE_SKILLS['software developer'])
    names={x['name'].lower() for x in skills}
    gaps=[x for x in req if x.lower() not in names]
    academic=round(min(100, (s.get('cgpa') or 0)*10)) if s.get('cgpa') else 0
    technical=round(sum((x.get('score') or {'beginner':35,'intermediate':65,'advanced':90}.get((x.get('level') or '').lower(),50)) for x in skills)/len(skills)) if skills else 20
    solved=sum(x.get('problems_solved') or 0 for x in coding); coding_score=min(100,round(solved/3.5)) if coding else 10
    project_score=min(100,35+len(projects)*20)
    overall=round(0.25*academic+0.25*technical+0.2*coding_score+0.2*project_score+0.1*min(100,len(academics)*15+len(performance)*10))
    overall=max(5,min(100,overall))
    summary=f'Your current profile is strongest in {len(skills)} recorded skills and {len(projects)} project(s). For {s.get("target_role") or "your target role"}, focus next on the highest-priority skill gaps and measurable coding/project evidence.'
    roadmap=[{'title':f'Close the {gaps[0]} gap','description':f'Build practical evidence in {gaps[0]} through a guided course and a small project.'}] if gaps else []
    if solved<150: roadmap.append({'title':'Strengthen DSA','description':f'Build from {solved} solved problems toward 150 with consistent practice.'})
    if len(projects)<3: roadmap.append({'title':'Build portfolio depth','description':'Complete another production-style project with GitHub documentation, testing and deployment.'})
    return {'overall':overall,'summary':summary,'gaps':gaps[:6],'roadmap':roadmap[:5],'score_breakdown':{'academic':academic,'technical':technical,'coding':coding_score,'projects':project_score,'career_readiness':overall}}

def recommendations(s, skills, projects, coding):
    role=(s.get('target_role') or 'Software Developer').lower(); req=ROLE_SKILLS.get(role,ROLE_SKILLS['software developer']); have={x['name'].lower() for x in skills}; gaps=[r for r in req if r.lower() not in have]
    learning=[{'title':g,'description':f'Learn {g} because it is a priority skill for your target role.','level':'Recommended'} for g in gaps[:4]]
    if not learning: learning=[{'title':'Advanced role-specific practice','description':'Deepen the skills already present through advanced projects and interview preparation.','level':'Recommended'}]
    projects_rec=[{'title':f'{role.title()} Portfolio Project','description':f'Build a real-world project using {", ".join(req[:4])}.','difficulty':'Intermediate','duration':'4–6 weeks','skills':req[:4]}]
    hacks=[{'title':'Relevant Student Hackathon (demo)','description':'Demo opportunity match based on your target role and skills. Verify the official event page before applying.','mode':'Online','match_score':min(95,60+len(skills)*5)}]
    jobs=[]
    for company,job,need in [('Microsoft','Software/Cloud Student Roles',['Python','Java','DSA']),('Google','Software Engineering Student Roles',['Python','C++','DSA']),('Adobe','Software Engineering Student Roles',['Java','C++','DSA'])]:
        match=55+sum(1 for n in need if n.lower() in have)*12+min(15,len(projects)*5)
        jobs.append({'company':company,'role':job,'match_score':min(95,match),'reason':'AI-based estimate from your recorded skills, projects and coding evidence. This is not a hiring decision.'})
    return learning,projects_rec,hacks,jobs

def action_tasks(s, skills, projects, coding):
    solved=sum(x.get('problems_solved') or 0 for x in coding); tasks=[]
    if len(skills)<5: tasks.append(('Add 2–3 verified technical skills','Improves skill evidence and matching accuracy.','HIGH'))
    if solved<50: tasks.append(('Solve 15 DSA problems','Build consistent problem-solving evidence.','HIGH'))
    elif solved<150: tasks.append(('Solve 20 medium-level DSA problems','Strengthen interview readiness.','HIGH'))
    else: tasks.append(('Take one timed DSA assessment','Maintain problem-solving speed and accuracy.','MEDIUM'))
    if len(projects)<3: tasks.append(('Build one production-style project','Increases portfolio depth and practical evidence.','HIGH'))
    tasks += [('Improve GitHub README for your strongest project','Makes project impact easier to verify.','MEDIUM'),('Review 5 relevant opportunities','Build awareness of current role requirements.','MEDIUM'),('Practice 5 technical interview questions','Improve interview readiness.','MEDIUM')]
    return tasks
